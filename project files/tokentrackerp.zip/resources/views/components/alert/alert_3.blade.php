<div class="card mt-5">

    <div class="card-header">
        Dismissing alert using simple function to dismiss alert , 
        alert will take class animated & fadeOut and elemnt will be removed <br>
        for more check <span class="badge badge-primary">alert.js</span> 
        you have to follow the same structure
    </div>

    <div class="card-body">        
        
        <div class="alert mb-5 alert-close">
            <button class="alert-btn-close"><i class="fad fa-times"></i></button>
            <span>A simple alert it out!</span>
        </div>

        <div class="alert alert-default alert-close mb-5">
            <button class="alert-btn-close"><i class="fad fa-times"></i></button>
            <span>A simple alert it out!</span>
        </div>        

        <div class="alert alert-light alert-close mb-5">
            <button class="alert-btn-close"><i class="fad fa-times"></i></button>
            <span>A simple alert it out!</span>
        </div>

        <div class="alert alert-dark alert-close mb-5">
            <button class="alert-btn-close"><i class="fad fa-times"></i></button>
            <span>A simple alert it out!</span>
        </div>

        <div class="alert alert-success alert-close mb-5">
            <button class="alert-btn-close"><i class="fad fa-times"></i></button>
            <span>A simple alert it out!</span>
        </div>

        <div class="alert alert-error alert-close">
            <button class="alert-btn-close"><i class="fad fa-times"></i></button>
            <span>A simple alert it out!</span>
        </div>

    </div>

    <div class="card-footer">
        <script type="text/plain" class="language-html">
            <div class="alert mb-5 alert-close">
                <button class="alert-btn-close">
                    <i class="fad fa-times"></i>
                </button>
                <span>A simple alert it out!</span>
            </div>
    
            <div class="alert alert-default alert-close mb-5">
                <button class="alert-btn-close">
                    <i class="fad fa-times"></i>
                </button>
                <span>A simple alert it out!</span>
            </div>        
    
            <div class="alert alert-light alert-close mb-5">
                <button class="alert-btn-close">
                    <i class="fad fa-times"></i>
                </button>
                <span>A simple alert it out!</span>
            </div>
    
            <div class="alert alert-dark alert-close mb-5">
                <button class="alert-btn-close">
                    <i class="fad fa-times"></i>
                </button>
                <span>A simple alert it out!</span>
            </div>
    
            <div class="alert alert-success alert-close mb-5">
                <button class="alert-btn-close">
                    <i class="fad fa-times"></i>
                </button>
                <span>A simple alert it out!</span>
            </div>
    
            <div class="alert alert-error alert-close">
                <button class="alert-btn-close">
                    <i class="fad fa-times"></i>
                </button>
                <span>A simple alert it out!</span>
            </div>
        </script>
    </div>
</div>