<div class="card mt-5">

    <div class="card-header">
        any <span class="badge badge-primary">a tag</span> inside alert will have font <span class="badge badge-primary">font-weight: 900</span>
    </div>

    <div class="card-body">

        <div class="alert mb-5">
            a simple alert it out! with <a href="#">alert link</a> click it now.
        </div>

        <div class="alert alert-default mb-5">
            a simple alert it out! with <a href="#">alert link</a> click it now.
        </div>

        <div class="alert alert-light mb-5">
            a simple alert it out! with <a href="#">alert link</a> click it now.
        </div>

        <div class="alert alert-dark mb-5">
            a simple alert it out! with <a href="#">alert link</a> click it now.
        </div>

        <div class="alert alert-success mb-5">
            a simple alert it out! with <a href="#">alert link</a> click it now.
        </div>

        <div class="alert alert-error">
            a simple alert it out! with <a href="#">alert link</a> click it now.
        </div>

    </div>

    <div class="card-footer">
        <script type="text/plain" class="lang-html">

            <div class="alert mb-5">
                a simple alert it out! with 
                <a href="#">alert link</a> 
                click it now.
            </div>            

            <div class="alert alert-default mb-5">
                a simple alert it out! with 
                <a href="#">alert link</a> 
                click it now.
            </div>
    
            <div class="alert alert-light mb-5">
                a simple alert it out! with 
                <a href="#">alert link</a> 
                click it now.
            </div>
    
            <div class="alert alert-dark mb-5">
                a simple alert it out! with 
                <a href="#">alert link</a> 
                click it now.
            </div>
    
            <div class="alert alert-success mb-5">
                a simple alert it out! with 
                <a href="#">alert link</a> 
                click it now.
            </div>
    
            <div class="alert alert-error">
                a simple alert it out! with 
                <a href="#">alert link</a> 
                click it now.
            </div>

        </script>
    </div>

</div>