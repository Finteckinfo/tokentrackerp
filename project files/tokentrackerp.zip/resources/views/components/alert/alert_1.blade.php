<div class="card">

    <div class="card-header">
        simple alert - you can always use <span class="badge badge-primary">.alert</span> class along with <span class="badge badge-primary">.alert-(type)</span>
    </div>

    <div class="card-body">        
        
        <div class="alert mb-5">
            A simple alert it out!!
        </div>

        <div class="alert alert-default mb-5">
            A simple alert it out!
        </div>        

        <div class="alert alert-light mb-5">
            A simple alert it out!
        </div>

        <div class="alert alert-dark mb-5">
            A simple alert it out!
        </div>

        <div class="alert alert-success mb-5">
            A simple alert it out!
        </div>

        <div class="alert alert-error">
            A simple alert it out!
        </div>

    </div>

    <div class="card-footer">
        <script type="text/plain" class="language-html">
            <div class="alert mb-5">
                A simple alert it out!
            </div>
    
            <div class="alert alert-default mb-5">
                A simple alert it out! 
            </div>        
    
            <div class="alert alert-light mb-5">
                A simple alert it out!
            </div>
    
            <div class="alert alert-dark mb-5">
                A simple alert it out!
            </div>
    
            <div class="alert alert-success mb-5">
                A simple alert it out!
            </div>
    
            <div class="alert alert-error">
                A simple alert it out!
            </div>
        </script>
    </div>
</div>