<h1 class="h5">alerts</h1>
<p>Use cleopatra custom alerts styles for actions , notifcations etc.</p>
<p>so far there's just 3 type of alerts feel free to submit a pull request</p>

<hr class="my-5">