<template>
  <div
    class="flex content-stretch gap-1 p-2 rounded-sm bg-gray-50 dark:bg-gray-700"
  >
    <slot></slot>
  </div>
</template>
