<template>
  <button class="group ic-btn">
    <slot></slot>
  </button>
</template>
